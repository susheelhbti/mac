export class CenterList{

  id: number;

}
