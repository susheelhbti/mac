export class Category{

  id: number;

}
