export class TestList{

  id: number;
  Message:number;
  name:String;
  marks:number;
  negative_marks:number;
  duration_hour:number;
  duration_minute:number;
  description:String;

}
