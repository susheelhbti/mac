export class Question {

  id: number;
qid:number;
color:number
   selected: string;
}
