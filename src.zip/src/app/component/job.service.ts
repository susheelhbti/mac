import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Job } from '../models/job';
import {  CategoryList} from '../models/category-list';
import {ApiResponse} from "../models/api.response";
import {Category} from "../models/category.model";
import {Center} from "../models/center.model";
import {Test} from "../models/test.model";
import { CenterList } from '../models/center-list.model';
import { Student } from '../models/student.model';
import { User } from '../models/user.model';
import { Question } from '../models/question.model';

import { Observable } from 'rxjs';

 

@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor(private http: HttpClient) { }

  baseUrl: string = 'http://saksh.website/vapi/a8center/';
  
 

  
  

   


 

importmultiplequestions(id:any,id1:any) : Observable<ApiResponse> {
return this.http.get<ApiResponse>(this.baseUrl+'importmultiplequestions.php?id='+id+'&test_id='+id1)
  
}


importquestion(id:number,id1:any) : Observable<ApiResponse> {
return this.http.get<ApiResponse>(this.baseUrl+'importquestion.php?id='+id+'&test_id='+id1)
  
}

 createCategory(data) {
      return this.http.post( this.baseUrl+'tcreateCategory.php', data);
  } 



 getCategory() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allcategory.php');
  }

 categoryStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'categoryStatus.php?id='+ id);
    
  }


 deletetest(id:any) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'deletetest.php?id='+ id);
  }


 deletemylib(id:any) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'deletemylib.php?id='+ id);
  }


  deletequestion(id:any,test_id:any) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'deletequestion.php?id='+ id+'&test_id='+ test_id);
  }

teststudent(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'teststudent.php?test_id='+ id);
    
  }
  getCategoryById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getCategorybyId.php?id='+ id);
  }

  getCenter1(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getCenter.php?category_id='+ id);
  }

 getCenter() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allcenter.php');
  }

   getTest() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'alltest.php');
  }

  getTest1() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getTest.php');
  }

   editcenterbyid() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getcenterbyid.php');
  }

   getTest2(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getTest.php?center_id='+ id);
  }


getLibraryQuestions(id: any,test_id:any): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getLibrary_questions.php?library_id='+ id+'&test_id='+ test_id);
  }


   getLibrary(type:any,library_id:any) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getLibrary.php?type='+type+'&library_id='+library_id);
  }


   getAllLibrary(type:any ) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getAllLibrary.php?type='+type );
  }


    testdraft() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'alltestdraft.php');
  }

 NewupdateQuestion(question: Question,type:any): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'newupdateQuestion.php?type='+ type,question);
  }


 getQuestionById(id: number,test_id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getQuestionbyId.php?id='+ id+'&test_id='+ test_id);
  }


   getQuestion1(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getQuestion.php?test_id='+ id);
  }


 updateCategory(category: Category): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateCategory.php?id='+ category.id, category);
  }

createCenter(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createCenter.php', center);
  }
 
 createTest(test: Test): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createTest.php', test);
  }

  createQuestions(question: Question,id:number): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createQuestion.php?test_id='+id, question);
  }

  centerStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'centerStatus.php?id='+ id);

  }


  centerStatus11(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'centerStatus.php?id='+ id);

  }

   getCenterById(): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getCenterbyId.php');
  }

   updateCenter(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateCenter.php?id='+ center.id, center);
  }


  changepassword(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'changepassword.php',center);
  }


 editCenter(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'getcenterbyid1?id='+ center.id, center);
  }




   createStudent(student: Student): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createStudent.php', student);
  }

  testStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'testStatus.php?id='+ id);
    }

    publish_test(s:any,id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'publish_test.php?id='+ id+"&status="+s);
    }

 free_paid( id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'free_paid.php?id='+ id );
    }




 getTestById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getTestbyId.php?test_id='+ id);
  }

   sendtolibrary(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'sendtolibrary.php?test_id='+ id);
  }

TestById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'testbyid.php?test_id='+ id);
  }
  

  TestlibById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'testlibbyid.php?library_id='+ id);
  }

///
   getCenterById1(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getcenterbyid1.php?id='+ id);
  }

   updateCenter1(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateCenter.php?id='+ center.id, center);
  }

    updateTest(test: Test): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateTest.php?id='+ test.id, test);
  }
   createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'tcreateuser.php', user);
  }

  getUserById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getUserById.php?id='+ id);
  }

   updateUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateUser.php?id='+ user.id, user);
  }

  deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl +'tuser.php?id='+ id);
  }

  getUsers1() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'studentlist.php');
  }

getactiveUsers1() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'activestudent.php');
  }


gettopUsers1() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'topstudent.php');
  }


   getnewUsers() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'newstudentlist.php');
  }



   studentStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'studentStatus.php?id='+ id);
    
  }
newstudentStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'newstudentStatus.php?id='+ id);
    
  }

 getQuestions() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allquestions.php');
  }

    updateQuestion(question: Question): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateQuestion.php', question);
  }
}
