import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';

import { CenterList } from 'src/app/models/center-list.model';

@Component({
  selector: 'app-center-list',
  templateUrl: './center-list.component.html',
  styleUrls: ['./center-list.component.css']
})
export class CenterListComponent implements OnInit {
center : CenterList[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }
 addForm: FormGroup;
  
  ngOnInit() {

     this.jobService.getCenter()
      .subscribe( data => {
		  
        this.center = data.result ;
		console.log( this.center);
		   
      });



  }

 editQuestion(q:CenterList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/edit-center']);
   //alert(q.id.toString());
  };

  addCenter(): void {
    this.router.navigate(['/job/create'])
  }; 

  sendto(q:CenterList): void {
  window.localStorage.removeItem("centerId");
  window.localStorage.setItem("centerId", q.id.toString());
   this.router.navigate(['job/gettest']);
  }; 


 sendtostatus(q:CenterList): void {
  window.localStorage.removeItem("centerId");
  window.localStorage.setItem("centerId", q.id.toString());



  
    //alert( q.id.toString());
     this.jobService.centerStatus(+q.id.toString())
      .subscribe( data => {
      
        this.center = data.result ;
    console.log( this.center);

       this.jobService.getCenter()
      .subscribe( data => {      
        this.center = data.result ;
    console.log( this.center);
       
      });
         
      });



  }; 
}
