import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GettestComponent } from './gettest.component';

describe('GettestComponent', () => {
  let component: GettestComponent;
  let fixture: ComponentFixture<GettestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GettestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GettestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
