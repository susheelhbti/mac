import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';
import { TestList } from 'src/app/models/test-list.model';
import { CenterList } from 'src/app/models/center-list.model';

@Component({
  selector: 'app-gettest',
  templateUrl: './gettest.component.html',
  styleUrls: ['./gettest.component.css']
})
export class GettestComponent implements OnInit {
test : TestList[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

ngOnInit() {

 

 let centerId = window.localStorage.getItem("centerId");
  //alert(centerId);
     this.jobService.getTest2(+centerId)
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
       
      });

  }

 editQuestion(q:CenterList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/test-update']);
   //alert(q.id.toString());
  };

  addTest(): void {
   this.router.navigate(['job/test']);
  }; 

 sendto(q:TestList): void {
  window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());
   this.router.navigate(['job/getquestion']);
  }; 


sendtostatus(q:TestList): void {
  window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());

   // alert( q.id.toString());
     this.jobService.testStatus(+q.id.toString())
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
         
      });



  }; 
}
