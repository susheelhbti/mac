import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";

import { JobService } from '../../job.service';
import { CenterUpdate } from 'src/app/models/center-update.model';

@Component({
  selector: 'app-edit-center',
  templateUrl: './edit-center.component.html',
  styleUrls: ['./edit-center.component.css']
})
export class EditCenterComponent implements OnInit {
 editForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

 ngOnInit() {




    let editQuestionId = window.localStorage.getItem("editQuestionId");
    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['job/category-list']);
      return;
    }
    alert(editQuestionId);
    this.editForm = this.formBuilder.group({
      id: [''],   about: [''], 
      username: [''], email: [''],
       password: [''] ,mobile_no: [''],category_id: [''],logo: [''], status: [''],
      name: ['', Validators.required] ,roll:['']
    
    });
    this.jobService.getCenterById1(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);

      });
  }


onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateCenter1(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Center updated successfully.');
            this.router.navigate(['job/center-list']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }

}
