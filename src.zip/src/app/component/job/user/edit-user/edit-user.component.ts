import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import { JobService } from '../../../job.service';
 import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-edit-user',
   
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
	 
	

  user: User;
  editForm: FormGroup;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
  ngOnInit() {
    let userId = window.localStorage.getItem("editUserId");
    if(!userId) {
      alert("Invalid action.")
      this.router.navigate(['ob/user/list-user']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''], name: [''] ,father_name: [''] ,father_mobile_no: [''] ,status: [''],
      mobile_no: ['', Validators.required]  ,center_id:[''],created_at:[''],updated_at:[''],marks:[''],member_type:['']
    });
    this.jobService.getUserById(+userId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });
  }

  onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateUser(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert('Student details updated successfully.');
            this.router.navigate(['job/user/list-user']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }

}
