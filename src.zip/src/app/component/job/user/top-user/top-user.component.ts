import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

import { JobService } from '../../../job.service';
 import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-top-user',
  templateUrl: './top-user.component.html',
  styleUrls: ['./top-user.component.css']
})
export class TopUserComponent implements OnInit {
users: User[];

  constructor(private router: Router, private jobService: JobService) { }


  ngOnInit() {


    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');
  //alert(token);
  
    this.jobService.gettopUsers1()
      .subscribe( data => {
        this.users = data.result;
      });
  }


  editUser(user: User): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['job/user/edit-user']);
  };

  addUser(): void {
    this.router.navigate(['job/user/add-user']);
  }; 
  addUser1(): void {
    this.router.navigate(['job/user/new-user']);
  }; 
  addUser2(): void {
    this.router.navigate(['job/student']);
  }; 


sendtostatus(user:User): void {
 
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());

  
   // alert(user.id.toString());
     this.jobService.studentStatus(+user.id.toString())
      .subscribe( data => {
      
        this.users = data.result ;
    console.log( this.users);
    this.jobService.getUsers1()
      .subscribe( data => {
        this.users = data.result;
      });

         
      });



  }; 
  
}
