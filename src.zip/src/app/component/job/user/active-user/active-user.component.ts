import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

import { JobService } from '../../../job.service';
 import { User } from 'src/app/models/user.model';
 
@Component({
  selector: 'app-active-user',
  templateUrl: './active-user.component.html',
  styleUrls: ['./active-user.component.css']
})
export class ActiveUserComponent implements OnInit {
  users: User[];
loading:any;

testCount :any;
  constructor(private router: Router, private jobService: JobService) { }


  ngOnInit() {

this.loading=true;
this.testCount=1;
    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');
  //alert(token);
  
    this.jobService.getactiveUsers1()
      .subscribe( data => {
        this.users = data.result;
        this.testCount= this.users.length;
       console.log(this.testCount);


this.loading=false;
      });
  }


  editUser(user: User): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['job/user/edit-user']);
  };

  addUser(): void {
    this.router.navigate(['job/user/add-user']);
  }; 
  addUser1(): void {
    this.router.navigate(['job/user/new-user']);
  }; 
  addUser2(): void {
    this.router.navigate(['job/student']);
  }; 


sendtostatus(user:User): void {
 
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());

  
    //alert(user.id.toString());
     this.jobService.studentStatus(+user.id.toString())
      .subscribe( data => {
      
        this.users = data.result ;
    console.log( this.users);
    this.jobService.getUsers1()
      .subscribe( data => {
        this.users = data.result;
      });

         
      });



  }; 
  

}
