import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';
import { CategoryList } from 'src/app/models/category-list';
import {first} from "rxjs/operators";

@Component({
  selector: 'app-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.css']
})
export class CenterComponent implements OnInit {

category : CategoryList[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  addForm: FormGroup;

  ngOnInit() {
  this.addForm = this.formBuilder.group({
      id: [],
      current_password: ['', Validators.required], 
       confirm_password: ['', Validators.required],
       new_password:['']
     
     
    });


  }

  onSubmit() {

  if(this.addForm.value.confirm_password==this.addForm.value.new_password){



    this.jobService.changepassword(this.addForm.value)
      .pipe(first())
      .subscribe(
        data => {
          
            alert( data.Message);
        
        },
        error => {
        alert(error);
           
        });


      }
 else
 {

alert("New Password and Confirm Password did not match");

 }
  }

}
