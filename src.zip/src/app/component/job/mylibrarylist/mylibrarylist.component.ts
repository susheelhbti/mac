import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';

import { TestList } from 'src/app/models/test-list.model';

 import { User } from 'src/app/models/user.model';
 import { Question } from 'src/app/models/question.model';

@Component({
  selector: 'app-mylibrarylist',
  templateUrl: './mylibrarylist.component.html',
  styleUrls: ['./mylibrarylist.component.css']
})
export class MylibrarylistComponent implements OnInit {
test : TestList[];

questions : Question[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  ngOnInit() {

  //let test_type = window.localStorage.getItem("test_type");
  //  let test_id1 = window.localStorage.getItem("test_id1");
  //alert("cid"+test_id1);
     this.jobService.getAllLibrary('local')
      .subscribe( data => {
      
        this.test = data.result ;
        console.log(this.test);

  
      



       
      });
  }



   deletemylib(q: TestList): void {
    this.jobService.deletemylib(+q.id)
      .subscribe( data => {
        this.questions = data.result;
        alert("Deleted Successfully");

         this.jobService.getAllLibrary('local')
      .subscribe( data => {
      
        this.test = data.result ;
        console.log(this.test);
       
      });

           });

           }

}
