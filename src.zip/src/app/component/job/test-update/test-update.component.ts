import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";


import { JobService } from '../../job.service';

import { TestUpdate } from 'src/app/models/test-update.model';

@Component({
  selector: 'app-test-update',
  templateUrl: './test-update.component.html',
  styleUrls: ['./test-update.component.css']
})
export class TestUpdateComponent implements OnInit {

test: TestUpdate; 
  editForm: FormGroup;

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

 ngOnInit() {




    let editQuestionId = window.localStorage.getItem("editQuestionId");


    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['job/test-list']);
      return;
    }




   // alert(editQuestionId);
    this.editForm = this.formBuilder.group({
      id: [''], center_id: [''], status: [''], duration_hour: [''], duration_minute: [''], question: [''],  marks: [''],  description: [''], negativemarks: [''], created_at: [''], updated_at: [''], 
      name: ['', Validators.required]  ,test_type:['']
    });




    this.jobService.getTestById(+editQuestionId)
      .subscribe( data => {
    //  alert("ssss");

      console.log(data);


        this.editForm.setValue(data.result);



      });



  }


onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Test updated successfully.');
            this.router.navigate(['job/testdraft']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }

}
