import { Component, OnInit , Inject,ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
import { CenterList } from 'src/app/models/center-list.model';
import { TestList } from 'src/app/models/test-list.model';



import {UpdateComponent} from "../update/update.component";

//import { ModalController } from '@angular/angular';
//import { UpdateComponent } from './job/question/update/update.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';


import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';




@Component({
  selector: 'app-lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.css']
   

})
export class ListsComponent implements OnInit {
questions : Question[];
questions2 : Question[];
test : TestList[];

center : CenterList[];
 closeResult: string;
 public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  page;
  title: string;
  loading:any;
QuestionN:any;
test1:any;
testCount :any;
name;
marks;
negativemarks;
duration_hour;
duration_minute;
description;
id;
descriptionmsg;
selectedAll;
savetest;

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { 
  
  }
 
addForm: FormGroup;
 async ngOnInit() {

  // let editQuestionId = window.localStorage.getItem("cid");
  let testId1 = window.localStorage.getItem("testId");
//alert(testId1);




  this.addForm = this.formBuilder.group({
      id: [],
      question: ['', Validators.required], 
    
    });
  this.test=[ {id:3,Message:0,name:'abc',marks:3,negative_marks:3,duration_hour:3,duration_minute:3,description:'abc'}];

this.loading=true;
this.testCount=1;
this.savetest=true;

    let cid = window.localStorage.getItem("testId");
  //alert(cid);
     this.jobService.TestById(+cid)
      .subscribe( data => {
      
        this.test = data.result ; 
        this.name=data.result.name;
        this.marks=data.result.marks;
        this.negativemarks=data.result.negativemarks;
        this.duration_hour=data.result.duration_hour;
        this.duration_minute=data.result.duration_minute;
        this.description=data.result.description;
if(this.description.length>1)
        this.descriptionmsg=""
        else
        this.descriptionmsg="Test Instructions"
        this.id=data.result.id;


        //console.log(this.test.name);
      });



let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);

this.loading=false;

      });


  }


  selectAll() {
  

    for (var i = 0; i < this.questions.length; i++) {
    this.questions[i].selected ='true';
 
    }
  }

 checkIfAllSelected() {
    this.selectedAll = this.questions.every(function(item:any) {
        return item.selected == 'true';
      })
  }



 
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
  

  open(content) {
    
    let editQuestionId = window.localStorage.getItem("testId");
//alert(editQuestionId);

    if(!editQuestionId) {
      alert("Invalid action.")
      //this.router.navigate(['job/test-list']);
      return; 
    }

 // alert(editQuestionId);
    this.editForm = this.formBuilder.group({
      name: ['', Validators.required],id: [''], center_id: [''], duration_hour: [''],duration_minute: [''] ,status: [''], question: [''],  marks: [''],  description: [''], created_at: [''], updated_at: [''], test_type: [''], negativemarks: [''],draft_status:['']
       
    });

//alert(editQuestionId);
    this.jobService.getTestById(+editQuestionId)
      .subscribe( data => {
    //  alert("ssss");

      console.log(data);
        this.editForm.setValue(data.result);
      });

    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason1(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }




  open2(content1) {

  
    let editQuestionId = window.localStorage.getItem("testId");
//alert(editQuestionId);

    if(!editQuestionId) {
     // alert("Invalid action.")
      //this.router.navigate(['job/test-list']);
      return; 
    }

  //alert(editQuestionId);
    this.editForm = this.formBuilder.group({
        name: ['', Validators.required],id: [''], center_id: [''], duration_hour: [''], duration_minute: [''], status: [''], question: [''],  marks: [''],  description: [''], created_at: [''], updated_at: [''],negativemarks: [''],test_type: [''],draft_status:['']
       
    });


    this.jobService.getTestById(+editQuestionId)
      .subscribe( data => {

      console.log(data);

        this.editForm.setValue(data.result);

      });

    this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason2(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  

  private getDismissReason(reason: any): string {

    console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {



          let cid = window.localStorage.getItem("testId");
  //alert(cid);
     this.jobService.TestById(+cid)
      .subscribe( data => {
      
        this.test = data.result ; 
        this.name=data.result.name;
        this.marks=data.result.marks;
        this.negativemarks=data.result.negativemarks;
        this.duration_hour=data.result.duration_hour;
        this.duration_minute=data.result.duration_minute;
        this.description=data.result.description;
if(this.description.length>1)
        this.descriptionmsg=""
        else
        this.descriptionmsg="Test Instructions"
        this.id=data.result.id;


        //console.log(this.test.name);
      });

          let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);



      });



            //alert(' Test updated successfully.');
            this.router.navigate(['job/question/listquestion']);

          }
          else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });


    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }





  }



  editQuestion(q: Question): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/question/updatequestion']);
  };

  deleteQuestion(q: Question): void {
    let cid = window.localStorage.getItem("testId");
    this.jobService.deletequestion(+q.id,+cid)
      .subscribe( data => {
        this.questions = data.result;
     

 console.log("ss");
     //this.router.navigate(['job/question/listquestion']);
     let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;

        });
        });
  };



onSubmit() {
 //let cid = window.localStorage.getItem("testId");
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Question updated successfully.');

let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);



      });




            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }
   
 
  onSubmit1() {
   console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            //alert(' Test Instructions updated successfully.');

            let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);



      });







            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });

    
  }
  

sendtostatus(editQuestionId1): void {


     this.jobService.testStatus(+editQuestionId1)
.subscribe( data => {
      

       if(data.Message==0){
          alert("Question updated succesfully");
     this.jobService.testdraft()
          .subscribe( data => {
          this.savetest='true';
          
            this.test = data.result ;
       // console.log( "ms1",this.test);
        this.router.navigate(['job/testdraft']);
             
           });
       }
if(data.Message==1){
this.savetest='false';

alert("Please  updated Your Questions")
  
}



      });


  }; 

mylibrary(name1,id1,type){

 
   window.localStorage.removeItem("test_name");
    window.localStorage.setItem("test_name", name1);
   window.localStorage.removeItem("test_id1");
    window.localStorage.setItem("test_id1", id1);
     window.localStorage.removeItem("test_type");
    window.localStorage.setItem("test_type", type);
  this.router.navigate(['job/mylibrary']);
}


globallibrary(name1,id1){
// alert(name1);
   window.localStorage.removeItem("test_name");
    window.localStorage.setItem("test_name", name1);
   window.localStorage.removeItem("test_id1");
    window.localStorage.setItem("test_id1", id1);
  this.router.navigate(['job/globallibrary']);
}

deleteFoodSelected(){

         this.questions2= this.questions.filter(_ => _.selected);
 
var ids = [];

 

       for (var food in this.questions2) {

                ids.push(this.questions2[food].id);
     
          }

         


  var is= ids.toString();

 let testId = window.localStorage.getItem("testId");
 
 
 this.jobService.deletequestion(is,+testId)
             .subscribe(data =>{
              console.log(data)


 let testId = window.localStorage.getItem("testId");
             
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);

this.loading=false;

      });




      
             }   
             )  
 
//  alert("Sucessfully Deleted");
      
 }

  onSubmit5() {
  let testId = window.localStorage.getItem("testId");
    this.jobService.createQuestions(this.addForm.value,+testId)
      .subscribe( data => {
     // alert("Question Create successfully" );
this.addForm.reset();
        


     let testId = window.localStorage.getItem("testId");

     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;



        });
      //this.router.navigate(['job/question/listquestion']);
      }); 
  }


sendtolibrary(test_id){
//alert(test_id);
this.jobService.sendtolibrary(+test_id)
      .subscribe( data => {
        this.questions = data.result ;
       // alert("Add test to library");
        this.router.navigate(['job/mylibrarylist']);



        });
  
}
          

}
