import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";

import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
 
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
//import MathType from '@wiris/mathtype-ckeditor5';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})


export class UpdateComponent implements OnInit {

 
   public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  questions : Question[];
  data;
  loading:any;
QuestionN:any;
qId:any;

testCount :any;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ) { }

  //qId:any;



  
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
	



  ngOnInit() {



this.loading=true;

    let editQuestionId = window.localStorage.getItem("editQuestionId");

    this.qId=parseInt(editQuestionId);


    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['listquestion']);
      return;
    }


    this.editForm = this.formBuilder.group({
      id: [''], qid: [''], test_id: [''], a1: [''],   a2: [''],   a3: [''],   a4: [''],right_answer: [''], solution: [''], created_at: [''], updated_at:[''],shownext:[''],showprevious:[''],qe:[''],qs:[''],library_question_id:[''],
      question: ['', Validators.required]  
    });

  let cid = window.localStorage.getItem("testId");
  //alert(cid);
    this.jobService.getQuestionById(+editQuestionId,+cid)
      .subscribe( data => {
        this.editForm.setValue(data);

this.loading=false;
      

      });
  }

  onSubmit() {
 // let cid = window.localStorage.getItem("testId");
	 // console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(!data['Error']) {
            alert(' Question updated successfully.');
            this.router.navigate(['job/question/listquestion']);
          }

          if(data['Error']) {
             alert('Please updated your question');
             this.router.navigate(['job/question/listquestion']);
          }
        },
        error => {
          alert(error);
        });
  }


onSubmit1() {
  //let cid = window.localStorage.getItem("testId");
 //   console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(!data['Error']) {
            alert(' Question updated successfully.');
            //this.router.navigate(['job/question/listquestion']);
          }

          if(data['Error']) {
             alert('Please updated your question');
             //this.router.navigate(['job/question/listquestion']);
          }
        },
        error => {
          alert(error);
        });
  }
/*

next(){

this.loading=true;
let editQuestionId = window.localStorage.getItem("editQuestionId");

 this.qId=parseInt(editQuestionId);

  this.qId=this.qId+1;

  let cid = window.localStorage.getItem("testId");
 
    this.jobService.updateQuestion(this.editForm.value,+cid)
      .pipe(first())
      .subscribe(
        data => { 

window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId",this.qId);

             if(!data['Error']) {
             this.loading=false;
            //alert(' Question updated successfully.');
            //this.router.navigate(['job/question/listquestion']);
          }

          if(data['Error']) {
             alert('Please updated your question');
             this.loading=false;
          }
        },
        error => {
          alert(error);
        });
 
let cid = window.localStorage.getItem("testId");

this.jobService.getQuestionById(this.qId,+cid,'next')
      .subscribe( data => {
        this.editForm.setValue(data);
      });2



}*/



 onSubmit2() {
 
    console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          this.editForm.setValue(data);
        },
        error => {
          alert(error);
        });
  }




submitclick(type:any){



this.jobService.NewupdateQuestion(this.editForm.value,type)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
  
}



/*
previous(){


this.qId=this.qId-1;
 let cid = window.localStorage.getItem("testId");
window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId",this.qId);

this.jobService.getQuestionById(this.qId,+cid,'previous')
      .subscribe( data => {
        this.editForm.setValue(data);
      });

      

}*/


}


