import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MylibraryquestionComponent } from './mylibraryquestion.component';

describe('MylibraryquestionComponent', () => {
  let component: MylibraryquestionComponent;
  let fixture: ComponentFixture<MylibraryquestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MylibraryquestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MylibraryquestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
