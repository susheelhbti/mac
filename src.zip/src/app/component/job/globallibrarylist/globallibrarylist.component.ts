import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';

import { TestList } from 'src/app/models/test-list.model';

 import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-globallibrarylist',
  templateUrl: './globallibrarylist.component.html',
  styleUrls: ['./globallibrarylist.component.css']
})

export class GloballibrarylistComponent implements OnInit {
test : TestList[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  ngOnInit() {

  //let test_type = window.localStorage.getItem("test_type");
    //let test_id1 = window.localStorage.getItem("test_id1");
  //alert("cid"+test_id1);
     this.jobService.getAllLibrary('global')
      .subscribe( data => {
      
        this.test = data.result ;
        console.log(this.test);

  
      



       
      });
  }

}
