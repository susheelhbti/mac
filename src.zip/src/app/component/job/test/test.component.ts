import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators,NgModel} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { CenterList } from 'src/app/models/center-list.model';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
center : CenterList[];
public show:boolean = false;
  public buttonName:any = 'Show';

  
  closeResult: string;

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { }

  addForm: FormGroup;

  ngOnInit() {
  let editQuestionId = window.localStorage.getItem("cid");
  this.addForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required], 
      
      duration_hour: ['0', Validators.required], 
      duration_minute: ['10', Validators.required], 
     
      description: [''],
      question: ['1', Validators.required],
       marks: ['4', Validators.required], 
       
 marks1: [''], 
       negativemarks:['0'],


       center_id:[editQuestionId],
       

     
    });


/*
     this.jobService.getCenter()
      .subscribe( data => {
		  
        this.center = data.result ;
		console.log( this.center);
		   
      });*/
  }


  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }


toggle() {
    this.show = !this.show;

    // CHANGE THE NAME OF THE BUTTON.
    if(this.show)  
      this.buttonName = "Hide";
    else
      this.buttonName = "Show";
  }



  onSubmit() {


if (this.addForm.invalid) {
         

alert("Please type test paper name");

 return
        }


if(parseInt(this.addForm.value.duration_hour)==0)
{
 

 


if(parseInt(this.addForm.value.duration_hour)==parseInt(this.addForm.value.duration_minute))
{
 
 alert("please select duration");

}
}
 
    this.jobService.createTest(this.addForm.value)
      .subscribe( data => {
      alert(data.message);
     // alert("Test added successfully" );


 
      window.localStorage.setItem("testId", data.result.id);
        this.router.navigate(['job/question/listquestion'], {        
    skipLocationChange: true
  });
      }); 
  }

}
