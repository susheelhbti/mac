import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GloballibraryquestionComponent } from './globallibraryquestion.component';

describe('GloballibraryquestionComponent', () => {
  let component: GloballibraryquestionComponent;
  let fixture: ComponentFixture<GloballibraryquestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GloballibraryquestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GloballibraryquestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
