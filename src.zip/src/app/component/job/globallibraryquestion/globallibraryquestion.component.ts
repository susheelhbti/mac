import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import { JobService } from '../../job.service';
import { Question } from 'src/app/models/question.model';
import { CenterList } from 'src/app/models/center-list.model';
import { TestList } from 'src/app/models/test-list.model';





//import { ModalController } from '@angular/angular';
//import { UpdateComponent } from './job/question/update/update.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';


import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-globallibraryquestion',
  templateUrl: './globallibraryquestion.component.html',
  styleUrls: ['./globallibraryquestion.component.css']
})
export class GloballibraryquestionComponent implements OnInit {

questions : Question[];

questions2 : Question[];
test : TestList[];

center : CenterList[];
 closeResult: string;
 public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  page;
  title: string;
  loading:any;
QuestionN:any;
test1:any;
testCount :any;
name;
marks;
negativemarks;
duration_hour;
duration_minute;
description;
id;
test2;
test_name1;

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { }
  addForm: FormGroup;
   ngOnInit() {

this.test=[ {id:3,Message:0,name:'abc',marks:3,negative_marks:3,duration_hour:3,duration_minute:3,description:'abc'}];

this.loading=true;
this.testCount=1;


   

 

  var library_id=14;


 let test_id = window.localStorage.getItem("test_id1");

  

     this.jobService.getLibraryQuestions(+library_id,+test_id)
      .subscribe( data => {

      console.log(data);
      
       
   this.questions = data.result ;

        //console.log(this.test.name);
      });

let lib_id = window.localStorage.getItem("libId");
     this.jobService.TestById(+lib_id)
      .subscribe( data => {
      
        this.test = data.result ; 
        this.name=data.result.name;
        this.marks=data.result.marks;
        this.negativemarks=data.result.negativemarks;
        this.duration_hour=data.result.duration_hour;
        this.duration_minute=data.result.duration_minute;
        this.description=data.result.description;
        this.id=data.result.id;


        //console.log(this.test.name);
      });
 let test_name = window.localStorage.getItem("test_name");
 this.test2=test_id;
 this.test_name1=test_name ;
 
  }

  importquestion(qid){

    let cid = window.localStorage.getItem("test_id1");
  
 
  this.jobService.importquestion(+qid,cid)
      .subscribe( data => {
       // this.questions = data.result ;
        console.log( this.questions);
 
        this.jobService.getQuestion1(+cid)
      .subscribe( data => {
       // this.questions = data.result ;

       alert("Imported Succesfully");


        });
});


     
  }

/////
importMultipleSelectedQuestions(){
    let cid = window.localStorage.getItem("test_id1");
         this.questions2= this.questions.filter(_ => _.selected);

            console.log(this.questions2);
 
var ids = [];

 

       for (var food in this.questions2) {

                ids.push(this.questions2[food].id);

                 this.jobService.importquestion(this.questions2[food].id,cid)
      .subscribe( data => {
        this.questions = data.result ;
        console.log( "question",this.questions);
        this.router.navigate(['job/testdraft']);
        });
     
          }

        


              let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);
 
 alert("Sucessfully imported");
      });
 
    
 

         
    
  
 }
  sendto(){
   this.router.navigate(['job/testdraft']);
  }

 ////////


}
