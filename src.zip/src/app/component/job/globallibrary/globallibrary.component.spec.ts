import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GloballibraryComponent } from './globallibrary.component';

describe('GloballibraryComponent', () => {
  let component: GloballibraryComponent;
  let fixture: ComponentFixture<GloballibraryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GloballibraryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GloballibraryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
