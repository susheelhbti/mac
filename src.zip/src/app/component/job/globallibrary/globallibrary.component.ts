import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';

import { TestList } from 'src/app/models/test-list.model';

 import { User } from 'src/app/models/user.model';


@Component({
  selector: 'app-globallibrary',
  templateUrl: './globallibrary.component.html',
  styleUrls: ['./globallibrary.component.css']
})
export class GloballibraryComponent implements OnInit {
test : TestList[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  ngOnInit() {


    let type1 = window.localStorage.getItem("test_type");

  //alert("cid",cid);
     this.jobService.getLibrary("local","14")
      .subscribe( data => {
      
        this.test = data.result ;
        console.log(this.test);
      



       
      });
  }

  sendto(lib_id){
  alert(lib_id);
  window.localStorage.removeItem("libId");
  window.localStorage.setItem("libId", lib_id);
   this.router.navigate(['job/globallibraryquestion']);
  }
}
