import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';

import { TestList } from 'src/app/models/test-list.model';


 import { Question } from 'src/app/models/question.model';
 


@Component({
  selector: 'app-testdraft',
  templateUrl: './testdraft.component.html',
  styleUrls: ['./testdraft.component.css']
})
export class TestdraftComponent implements OnInit {
test : TestList[];
questions : Question[];

loading:any;

testCount :any;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ) { }

  ngOnInit() {
this.loading=true;
this.testCount=1;

    let cid = window.localStorage.getItem("cid");
  //alert("cid",cid);
     this.jobService.testdraft()
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
    this.testCount= this.test.length;
       console.log(this.testCount);


this.loading=false;

       
      });

  }

 editQuestion(q:TestList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
    window.localStorage.removeItem("test_name");
    //window.localStorage.setItem("test_name", q.name);
     this.router.navigate(['job/test-update']);
  // alert(q.id.toString());
  };

   addTest(): void {
    this.router.navigate(['/job/test'])
  }; 



  sendto1(): void {
   let test_id = window.localStorage.getItem("testId");
   this.jobService.teststudent(+test_id)
.subscribe( data => {
      
        this.test = data.result ;
       console.log("msg",data);
  }); 
}



sendto(q:TestList): void {
  window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());
   this.router.navigate(['job/question/listquestion']);
  }; 


  free_paid( q:any): void {
  
 


     this.jobService.free_paid( q )
.subscribe( data => {
       
      
  let cid = window.localStorage.getItem("cid");
 this.jobService.testdraft()
      .subscribe( data => {
      
        this.test = data.result ;
     
           });
      });

      



  }; 
  sendtostatus(s:any,q:TestList): void {

    window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());
  let cid = window.localStorage.getItem("cid");
   // alert( q.id.toString());


     this.jobService.publish_test(s,+q.id.toString())
.subscribe( data => {
      
        this.test = data.result ;
       // console.log("msg",data);

  //  console.log( "msg",this.test);
    //console.log("msg",this.test.Message);

 //this.router.navigate(['job/question/listquestion']);
  let cid = window.localStorage.getItem("cid");
 this.jobService.testdraft()
      .subscribe( data => {
      
        this.test = data.result ;
    console.log("teststatus", this.test);
         //alert(this.test.Message);
           });
      });

      



  }; 




  opensnak(q:TestList): void {

}



   deletetest(q: TestList): void {
    this.jobService.deletetest(+q.id)
      .subscribe( data => {
        this.questions = data.result;
        alert("Deleted Successfully");
        let cid = window.localStorage.getItem("cid");
  //alert("cid",cid);
     this.jobService.testdraft()
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
    this.testCount= this.test.length;
       console.log(this.testCount);


this.loading=false;

       
      });
      })
}

}
