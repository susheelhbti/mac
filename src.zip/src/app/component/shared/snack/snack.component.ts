import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-snack',
  templateUrl: './snack.component.html',
  styleUrls: ['./snack.component.css']
})
export class SnackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
