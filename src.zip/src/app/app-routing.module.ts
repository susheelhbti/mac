import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';
import { CreateComponent } from './component/job/create/create.component';



import { DetailsComponent } from './component/job/details/details.component';
import { CategoryComponent } from './component/job/category/category.component';

 import {CategoryListComponent} from "./component/job/category-list/category-list.component";
 
 import {CategoryUpdateComponent} from "./component/job/category-update/category-update.component";

 import {CenterComponent} from "./component/job/center/center.component";
 import {CenterListComponent} from "./component/job/center-list/center-list.component";
 import {CenterUpdateComponent} from "./component/job/center-update/center-update.component";

 import {TestComponent} from "./component/job/test/test.component";
 import {TestListComponent} from "./component/job/test-list/test-list.component";
 import {TestUpdateComponent} from "./component/job/test-update/test-update.component";

import {StudentComponent} from "./component/job/student/student.component";
 
import { AuthGuard } from './authentication/guards/auth.guard';
import {GetcenterComponent } from './component/job/getcenter/getcenter.component';
import {GettestComponent} from "./component/job/gettest/gettest.component";
 
 import {TestdraftComponent} from "./component/job/testdraft/testdraft.component";


 import {AddUserComponent} from "./component/job/user/add-user/add-user.component";
import {ListUserComponent} from "./component/job/user/list-user/list-user.component";
import {EditUserComponent} from "./component/job/user/edit-user/edit-user.component";
import {ListsComponent} from "./component/job/question/lists/lists.component";

import {UpdateComponent} from "./component/job/question/update/update.component";
import { NewUserComponent } from './component/job/user/new-user/new-user.component';
import { ActiveUserComponent } from './component/job/user/active-user/active-user.component';

import { TopUserComponent } from './component/job/user/top-user/top-user.component';
import { MylibraryComponent } from './component/job/mylibrary/mylibrary.component';
import { MylibraryquestionComponent } from './component/job/mylibraryquestion/mylibraryquestion.component';
import { GloballibraryComponent } from './component/job/globallibrary/globallibrary.component';
import { GloballibraryquestionComponent } from './component/job/globallibraryquestion/globallibraryquestion.component';
import { GloballibrarylistComponent } from './component/job/globallibrarylist/globallibrarylist.component';
import { MylibrarylistComponent } from './component/job/mylibrarylist/mylibrarylist.component';
import { EditCenterComponent } from './component/job/edit-center/edit-center.component';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },

  { path: 'admin', component: LoginComponent },
{ path: 'center', component: LoginComponent },


  { path: 'register', component: RegisterComponent },
   { path: 'job/category-list', component: CategoryListComponent, canActivate: [AuthGuard]},
  { path: 'job/create', component: CreateComponent,canActivate: [AuthGuard] },


 
  { path: 'job/details/:id', component: DetailsComponent,canActivate: [AuthGuard] },
  { path: 'job/category', component: CategoryComponent, canActivate: [AuthGuard] },
  
  { path: 'job/center-list', component: CenterListComponent, canActivate: [AuthGuard]},
  { path: 'job/test-list', component: TestListComponent, canActivate: [AuthGuard]},
  { path: 'job/center', component: CenterComponent, canActivate: [AuthGuard]},
  { path: 'job/category-update', component: CategoryUpdateComponent, canActivate: [AuthGuard]},
   { path: 'job/test-update', component: TestUpdateComponent, canActivate: [AuthGuard]},
    { path: 'job/center-update', component: CenterUpdateComponent, canActivate: [AuthGuard]},
     { path: 'job/student', component: StudentComponent, canActivate: [AuthGuard]},
     { path: 'job/test', component: TestComponent, canActivate: [AuthGuard]},
  
  { path: 'job/gettest', component: GettestComponent , canActivate: [AuthGuard]},
  { path: 'job/getcenter', component: GetcenterComponent , canActivate: [AuthGuard]},
   { path: 'job/testdraft', component: TestdraftComponent , canActivate: [AuthGuard]},

{ path: 'job/user/add-user', component: AddUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/list-user', component: ListUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/edit-user', component: EditUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/new-user', component: NewUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/active-user', component: ActiveUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/top-user', component: TopUserComponent , canActivate: [AuthGuard]},
{ path: 'job/question/listquestion', component: ListsComponent, canActivate: [AuthGuard] },

{ path: 'job/question/updatequestion', component: UpdateComponent , canActivate: [AuthGuard]},
{ path: 'job/mylibrary', component: MylibraryComponent , canActivate: [AuthGuard]},
{ path: 'job/mylibraryquestion', component: MylibraryquestionComponent , canActivate: [AuthGuard]},
{ path: 'job/globallibrary', component:  GloballibraryComponent , canActivate: [AuthGuard]},
{ path: 'job/globallibraryquestion', component: GloballibraryquestionComponent , canActivate: [AuthGuard]},
{ path: 'job/mylibrarylist', component:  MylibrarylistComponent , canActivate: [AuthGuard]},
{ path: 'job/globallibrarylist', component:  GloballibrarylistComponent , canActivate: [AuthGuard]},

{ path: 'job/edit-center', component:   EditCenterComponent , canActivate: [AuthGuard]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
