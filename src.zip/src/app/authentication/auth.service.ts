import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AuthService {


  private readonly loginUrl = 'http://saksh.website/vapi/a8center/tlogin.php';
  private readonly registerUrl = 'http://saksh.website/vapi/a8center/register.php';

  constructor(
    private http : HttpClient
  ) {  }

  register(body) {
    return this.http.post(this.registerUrl, body);
  }

  login(body) {
    return this.http.post(this.loginUrl, body);
  }

  logout() {
    
if(window.confirm("Are you sure want Exit"))
{
    localStorage.clear();

    return true;
}
else
{
  return false;
}
  }

  isAuthenticated() {
    return localStorage.getItem('token') !== null;
    
  }


  isAdmin() {
  let roll = window.localStorage.getItem("roll");
  
    return parseInt(roll)!== 10;
    
  }

  getToken() {
    let token = localStorage.getItem('token');



    return token;
  }


  getBrand() {
    let token =  localStorage.getItem('c_name');



    return token;
  }


}